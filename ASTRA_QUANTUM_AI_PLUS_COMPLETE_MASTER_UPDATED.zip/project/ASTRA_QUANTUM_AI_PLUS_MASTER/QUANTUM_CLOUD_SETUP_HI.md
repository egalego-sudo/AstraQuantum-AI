# ASTRA QUANTUM AI PLUS — Quantum Cloud Integration

## वर्तमान स्थिति
ऐप में provider-neutral `QuantumCloudProvider` contract जोड़ा गया है। यह केवल integration boundary है; अभी कोई live provider adapter, API endpoint, authentication flow या cloud job submission सक्रिय नहीं है। इसलिए UI/दस्तावेज़ में cloud execution को उपलब्ध बताना गलत होगा।

## सुरक्षित अगला implementation path
1. पहले provider चुनें और उसकी मौजूदा official API documentation सत्यापित करें।
2. API token को Android APK में embed न करें। Mobile app → HTTPS backend → provider API का flow रखें।
3. Backend पर user authentication, rate limits, request validation, encrypted secret storage और job ownership checks लागू करें।
4. Backend adapter को `QuantumCloudProvider` contract के अनुरूप लागू करें; backend ID, qubit limit, shots, queue status और measurement counts provider से ही लें।
5. Hardware jobs के परिणाम को simulator output से स्पष्ट रूप से अलग दिखाएँ।

## महत्वपूर्ण वैज्ञानिक सीमा
फोन पर चलने वाला state-vector simulator classical computation है। वह quantum hardware नहीं है। वास्तविक hardware execution के लिए provider account, network, credentials और provider द्वारा समर्थित backend आवश्यक हैं।
