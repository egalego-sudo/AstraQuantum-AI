# ASTRA QUANTUM AI PLUS

**Full Name:** Advanced Scientific Thinking & Reasoning Architecture – Quantum Artificial Intelligence  
**Creator by Bittu Pandit**

Native Android app – Kotlin, Jetpack Compose, Material 3, MVVM-ready, Room.

## Implemented features

| Feature | Status | Notes |
|---------|--------|-------|
| Quantum Lab (state-vector) | **Fully implemented** | Multi-qubit simulator with real entanglement via CNOT, measurement, probabilities, history. Classical only. |
| Room Database | **Fully implemented** | ChatMessage, Project, Long-term Memory entities + DAOs + Repository |
| UI + Navigation | **Fully implemented** | Dashboard, Chat, Quantum, Projects, Settings + Creator credit on screens |
| Dark / Light theme | **Fully implemented** | |
| Hindi + English strings | **Fully implemented** | resources + values-hi |
| Gemini AI client | **Implemented (needs key)** | Free-tier Gemini 1.5 Flash. Property name: `AI_API_KEY` in local.properties → BuildConfig. |
| AI Chat integration | **Implemented** | ViewModel + Room persistence + context from history + long-term memory in system prompt + loading/error/retry + New/Delete chat + EN/HI language for replies |
| Persistent chat history | **Implemented** | Messages saved/restored via Room by conversationId |
| Long-term memory | **Connected** | Loaded into system prompt for every request; managed via repository |
| Projects as workspace | **Partially** | UI + Room entity; full AI workspace linking pending |
| Voice input (SpeechRecognizer) | **Not yet wired** | Permission present; integration pending |
| Text-to-Speech | **Not yet wired** | |
| PDF / TXT import | **Not yet wired** | |
| Image understanding | **Not yet wired** | Needs vision-capable model + key |
| Internet research + sources | **Partial** | Structured prompt via Gemini; real live search needs extra free search API |
| Language switch at runtime | **Partial** | Strings exist; full recreate/locale switch pending |
| Clear Memory with confirmation | **Partial** | Settings has button; confirmation dialog + repository call pending |
| Unit tests | **Present** | Quantum state-vector + entanglement tests |
| Debug APK | **Not built here** | Environment has no Android SDK / insufficient RAM |

## How to add your free Gemini API key (required for real AI)

1. Get a free key from Google AI Studio (https://aistudio.google.com/).
2. Create or edit `local.properties` in the project root:
   ```
   AI_API_KEY=your_actual_key_here
   ```
3. Rebuild the app. The key is injected into BuildConfig and never committed.

## Build instructions

1. Open the project in Android Studio (Ladybug or newer).
2. Let Gradle sync.
3. Run on emulator / device (API 26+).
4. Or `./gradlew assembleDebug` after proper Gradle wrapper setup.

## Important

- No fake AI responses are generated.
- Quantum module is classical simulation only; the UI states this clearly.
- Creator by Bittu Pandit appears on major screens.
- Never put real API keys in source control.

## Project structure (key packages)

```
com.bittupandit.astraquantumai
├── ai/               ← GeminiAiService + interfaces
├── quantum/          ← StateVectorSimulator (entanglement), QuantumCircuit
├── data/local/       ← Room entities, DAOs, Database, Repository
├── ui/screens/       ← Dashboard, Chat, QuantumLab, Projects, Settings
└── ...
```


## Build configuration update
- Kotlin 2.0.21 uses the matching Kotlin Compose Compiler Gradle plugin.
- Gemini model defaults to `gemini-2.5-flash`; override with `AI_MODEL` in `local.properties`.
- Research requests enable Gemini Google Search grounding. Grounding links are extracted when returned by the API.
- Projects and saved memory are backed by Room and persist locally.
- The active chat ID and chat language are restored from app preferences.

`local.properties` example:
```properties
AI_API_KEY=your_gemini_api_key
AI_MODEL=gemini-2.5-flash
```


## Important build note
The source ZIP originally omitted `gradle-wrapper.jar`. The included `gradlew` is a fallback shim that invokes a system Gradle installation; it is not a self-contained Gradle Wrapper. Use Android Studio or a Codespace with Gradle 8.9 installed. This edited ZIP has not been compiled in this environment because Android SDK/Gradle are unavailable here.

## Features added in this revision
- Persistent Room-backed projects with descriptions and delete action.
- Long-term memory add/list/delete controls in Settings.
- Chat history selection, and restoration of active conversation and language.
- Gemini model configured through `AI_MODEL`; research requests enable Google Search grounding and display returned source links.
- Voice dictation through Android speech recognition and optional text-to-speech playback for AI replies.
- Import `.txt` / `.md` text into the chat composer.
- Correct Kotlin 2.0.21 Compose compiler Gradle plugin configuration and launcher vector resources.

Not included yet: PDF text extraction, image uploads/vision, account sync/cloud backup, a secure server-side AI proxy, automated UI/instrumentation tests, and a verified release APK. Gemini Google Search grounding availability depends on the selected model, API project, region and current Google API rules.


## Phase 4 — Grover Search & Quantum Cloud boundary
- Added a 3-qubit Grover search demonstration for target `|101⟩`, with oracle phase marking and inversion-about-the-mean diffusion in the state-vector simulator.
- Added a provider-neutral quantum cloud interface and Hindi setup notes. No live provider adapter or cloud submission is enabled yet.
- Added a unit test for Grover target probability and state normalization.
- Version: 1.3.0 (Android build not verified in this environment).


## Phase 5 (v1.4.0)
Adds a portable quantum experiment report formatter and documents the secure backend steps required for a real quantum-cloud provider adapter. See `PHASE5_NOTES_HI.md`. The report formatter does not itself persist files or create PDFs, and no live hardware provider is connected.
