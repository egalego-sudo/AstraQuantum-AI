# ASTRA QUANTUM AI PLUS — इस संशोधन में किए गए बदलाव

## इस चरण में नए बदलाव (Phase 3)
- Chat में PDF import जोड़ा: PDFBox-Android से selectable text निकाला जाता है और चैट में जोड़ा जाता है। Scanned/image-only PDF के लिए OCR अभी शामिल नहीं है।
- Chat में image picker जोड़ा: चुनी हुई तस्वीर Gemini multimodal API को भेजकर हिंदी/अंग्रेज़ी में विश्लेषण कराया जा सकता है।
- Image upload के लिए 12 MB सीमा रखी गई है; फोटो का MIME type ContentResolver से लिया जाता है।
- App version को 1.2.0 / versionCode 3 किया गया।

## जो कोड जोड़ा/सुधारा गया
- Kotlin 2.0.21 के अनुरूप Compose Compiler Gradle plugin लगाया; पुरानी incompatible Compose compiler extension setting हटाई।
- Android launcher के लिए vector icon resources जोड़े और ऐप का नाम ASTRA QUANTUM AI PLUS किया।
- Gemini model को hard-coded `gemini-3.8-flash` से हटाकर configurable `AI_MODEL` बनाया; default `gemini-2.5-flash` है।
- Gemini API request में system instruction अलग field में भेजी जाती है।
- Deep Research स्क्रीन जोड़ी; Gemini Google Search grounding का अनुरोध करती है और API से मिले grounding source links दिखाती है।
- Projects स्क्रीन को Room Database से जोड़ा: create, list, description और delete अब persistent हैं।
- Settings में Long-term Memory जोड़ने, देखने और अलग-अलग हटाने की सुविधा जोड़ी।
- Chat का active conversation ID और language preference ऐप बंद/खोलने पर restore होते हैं।
- Chat history picker जोड़ा।
- Android Speech Recognizer से voice dictation और Text-to-Speech से AI replies सुनने की सुविधा जोड़ी।
- TXT/Markdown/PDF file import जोड़ा; चुनी हुई फाइल का text chat composer में आता है।
- Chat history query को नवीनतम बातचीत पहले दिखाने के लिए सुधारा।

## अभी भी बाकी / इस ZIP में शामिल नहीं
- सुरक्षित server-side API proxy; APK में रखी API key निकाली जा सकती है।
- वास्तविक account login, cloud sync और multi-device backup।
- पूरे ऐप की भाषा को system-wide बदलने वाला locale switch।
- Scanned PDF के लिए OCR।
- Automated UI/instrumentation tests और पूर्ण app regression testing।
- Gradle Wrapper JAR: मूल ZIP में यह अनुपस्थित था। इस ZIP का `gradlew` उपलब्ध system Gradle को चलाने वाला fallback है, self-contained wrapper नहीं।
- Signed release APK/AAB।

## Phase 3 सत्यापन स्थिति
- ZIP archive integrity और Android XML parsing जाँची गई।
- इस environment में Android SDK/Gradle उपलब्ध नहीं होने से PDFBox dependency resolve या Android compile/device test नहीं किया जा सका। इसलिए PDF/image सुविधाएँ source में जोड़ी गई हैं, लेकिन build/device पर सत्यापित नहीं हैं।

## सत्यापन स्थिति
- Quantum Kotlin source compile हुआ और छोटे smoke checks पास हुए।
- सभी XML resource files parse हुए।
- Android Gradle build यहां नहीं चलाया जा सका क्योंकि इस environment में Android SDK और Gradle installation उपलब्ध नहीं थे। इसलिए इस संशोधित ZIP को अभी compiled या device-tested न मानें।

## सुरक्षा और वैज्ञानिक सीमा
- फोन पर चलने वाला StateVectorSimulator एक classical state-vector simulation है; यह फोन को quantum computer नहीं बनाता।
- Bell/GHZ प्रयोग simulator में ideal state तैयार करते हैं; वास्तविक hardware noise और provider job execution अभी शामिल नहीं हैं।
- Android APK में compile-time API key रखी जाए तो उसे reverse engineering से निकाला जा सकता है। सार्वजनिक वितरण से पहले server-side proxy आवश्यक है।

## API setup
Build मशीन पर `local.properties` में रखें (इसे GitHub पर commit न करें):
```properties
AI_API_KEY=your_gemini_api_key
AI_MODEL=gemini-2.5-flash
```


## Phase 4 (16 Nov 2026)
- Quantum Lab में 3-qubit Grover Search demo जोड़ा: target `|101⟩`, phase oracle और diffusion operation।
- Grover smoke test `kotlinc` से सफल: 2 iterations के बाद target probability लगभग 94.53%, total probability 1.0।
- Provider-neutral `QuantumCloudProvider` contract और `QUANTUM_CLOUD_SETUP_HI.md` जोड़ा। यह live cloud integration नहीं है; कोई वास्तविक provider API call नहीं होती।
- JUnit regression test जोड़ा। Android Gradle build अब भी verify नहीं हुआ क्योंकि environment में Android SDK/Gradle wrapper उपलब्ध नहीं।
