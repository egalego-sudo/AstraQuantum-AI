# ASTRA QUANTUM AI — सुरक्षित AI Backend

यह backend Gemini API key को Android APK से बाहर रखता है। Android ऐप केवल `AI_BACKEND_URL` पर `/v1/generate` कॉल करता है।

## चलाने का तरीका
1. Node.js 20+ वाले server/hosting पर `backend/` फ़ोल्डर रखें।
2. `npm install` चलाएँ।
3. Hosting dashboard के Secret/Environment Variables में `GEMINI_API_KEY` और वैकल्पिक `GEMINI_MODEL` सेट करें। `.env` या असली key को GitHub/ZIP में कभी commit न करें।
4. `npm start` चलाएँ। HTTPS hosting अनिवार्य रखें। `/health` से health check करें।
5. Android project के `local.properties` में `AI_BACKEND_URL=https://आपका-डोमेन` सेट करके rebuild करें।

## महत्वपूर्ण सुरक्षा सीमा
यह starter IP-based rate limiting देता है, लेकिन public production release से पहले account authentication, per-user quotas, abuse monitoring, privacy/retention policy, billing limits और provider error redaction जोड़ना आवश्यक है। Mobile carrier NAT के कारण IP limit अकेली पर्याप्त पहचान नहीं है। Backend को deploy किए बिना AI feature काम नहीं करेगा।
