import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '12mb' }));
app.use(rateLimit({
  windowMs: 60_000,
  limit: Number(process.env.RATE_LIMIT_PER_MINUTE || 30),
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Too many requests. Please wait and try again.' }
}));

const apiKey = process.env.GEMINI_API_KEY;
const defaultModel = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const allowedModels = new Set(['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash']);

app.get('/health', (_req, res) => res.json({ ok: true, service: 'ASTRA QUANTUM AI backend' }));

app.post('/v1/generate', async (req, res) => {
  if (!apiKey) return res.status(503).json({ error: 'Backend provider key is not configured.' });
  const body = req.body || {};
  const model = allowedModels.has(body.model) ? body.model : defaultModel;
  if (!Array.isArray(body.contents) || body.contents.length === 0) {
    return res.status(400).json({ error: 'A non-empty contents array is required.' });
  }
  try {
    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          contents: body.contents,
          ...(body.systemInstruction ? { systemInstruction: body.systemInstruction } : {}),
          ...(Array.isArray(body.tools) ? { tools: body.tools } : {})
        }),
        signal: AbortSignal.timeout(100_000)
      }
    );
    const raw = await upstream.text();
    res.status(upstream.status).type('application/json').send(raw);
  } catch (error) {
    res.status(502).json({ error: 'AI provider request failed.', detail: String(error?.message || error).slice(0, 240) });
  }
});

app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => console.log(`ASTRA backend listening on ${port}`));
