@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed and this ZIP does not include gradle-wrapper.jar.
echo Open in Android Studio or a Codespace with Gradle installed.
exit /b 127
