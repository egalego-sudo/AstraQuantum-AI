package com.bittupandit.astraquantumai

import com.bittupandit.astraquantumai.quantum.QuantumCircuit
import com.bittupandit.astraquantumai.quantum.StateVectorSimulator
import org.junit.Assert.*
import org.junit.Test

class QuantumCircuitTest {

    @Test
    fun initialStateIsZero() {
        val sim = StateVectorSimulator(1)
        val probs = sim.probabilities()
        assertEquals(1.0, probs[0], 1e-6)
        assertEquals(0.0, probs[1], 1e-6)
    }

    @Test
    fun hadamardCreatesSuperposition() {
        val sim = StateVectorSimulator(1)
        sim.hadamard(0)
        val probs = sim.probabilities()
        assertEquals(0.5, probs[0], 1e-6)
        assertEquals(0.5, probs[1], 1e-6)
    }

    @Test
    fun cnotCreatesEntanglement() {
        val sim = StateVectorSimulator(2)
        sim.hadamard(0)
        sim.cnot(0, 1)
        // Bell state (|00⟩ + |11⟩)/√2
        val probs = sim.probabilities()
        assertEquals(0.5, probs[0], 1e-6) // |00⟩
        assertEquals(0.0, probs[1], 1e-6) // |01⟩
        assertEquals(0.0, probs[2], 1e-6) // |10⟩
        assertEquals(0.5, probs[3], 1e-6) // |11⟩
    }

    @Test
    fun circuitMeasureCollapses() {
        val circuit = QuantumCircuit(1)
        circuit.applyHadamard(0)
        val result = circuit.measureAll()
        assertTrue(result == 0 || result == 1)
        val probs = circuit.getProbabilities()
        assertTrue(probs[result] > 0.99)
    }

    @Test
    fun pauliXFlips() {
        val sim = StateVectorSimulator(1)
        sim.pauliX(0)
        val probs = sim.probabilities()
        assertEquals(0.0, probs[0], 1e-6)
        assertEquals(1.0, probs[1], 1e-6)
    }
}
