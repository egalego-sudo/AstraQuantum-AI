package com.bittupandit.astraquantumai.quantum

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GroverSearchTest {
    @Test fun threeQubitSearchAmplifiesMarkedState() {
        val circuit = QuantumCircuit(3)
        val iterations = circuit.runGrover(5)
        val probabilities = circuit.getProbabilities()
        assertEquals(2, iterations)
        assertTrue(probabilities[5] > 0.90)
        assertEquals(1.0, probabilities.sum(), 1e-9)
    }
}
