package com.bittupandit.astraquantumai.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bittupandit.astraquantumai.ai.ChatTurn
import com.bittupandit.astraquantumai.ai.GeminiAiService
import com.bittupandit.astraquantumai.data.local.entity.ChatMessageEntity
import com.bittupandit.astraquantumai.data.repository.AstraRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val language: String = "en" // "en" or "hi"
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AstraRepository(application)
    private val aiService = GeminiAiService()
    private val prefs = application.getSharedPreferences("astra_chat", android.content.Context.MODE_PRIVATE)

    private val _conversationId = MutableStateFlow(
        prefs.getString("active_conversation", null) ?: UUID.randomUUID().toString()
    )
    val conversationId: StateFlow<String> = _conversationId.asStateFlow()

    val messages: StateFlow<List<ChatMessageEntity>> = _conversationId
        .flatMapLatest { id -> repository.getMessages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(ChatUiState(language = prefs.getString("language", "en") ?: "en"))
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    fun setLanguage(lang: String) {
        prefs.edit().putString("language", lang).apply()
        _uiState.value = _uiState.value.copy(language = lang)
    }

    val conversations: StateFlow<List<String>> = repository.getConversationIds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun openConversation(id: String) {
        _conversationId.value = id
        prefs.edit().putString("active_conversation", id).apply()
        _uiState.value = _uiState.value.copy(error = null, isLoading = false)
    }

    fun newChat() {
        _conversationId.value = UUID.randomUUID().toString()
        prefs.edit().putString("active_conversation", _conversationId.value).apply()
        _uiState.value = _uiState.value.copy(error = null, isLoading = false)
    }

    fun deleteCurrentChat() {
        viewModelScope.launch {
            repository.clearConversation(_conversationId.value)
            newChat()
        }
    }

    fun showExternalError(message: String) { _uiState.value = _uiState.value.copy(error = message) }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || _uiState.value.isLoading) return
        val convId = _conversationId.value
        val lang = _uiState.value.language

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            // Save user message
            repository.saveMessage(convId, text.trim(), isUser = true)

            try {
                // Build context from recent history + long-term memory
                val history = repository.getMessagesOnce(convId)
                val memories = repository.getAllMemoriesOnce()
                val memoryBlock = if (memories.isNotEmpty()) {
                    "User long-term memory (respect and use when relevant):\n" +
                        memories.joinToString("\n") { "- ${it.key}: ${it.value}" }
                } else ""

                val systemPrompt = buildString {
                    append("You are ASTRA QUANTUM AI, a helpful scientific and general assistant. ")
                    append("Creator by Bittu Pandit. ")
                    append("Respond in ${if (lang == "hi") "Hindi" else "English"}. ")
                    append("Be clear, accurate, and concise. ")
                    if (memoryBlock.isNotEmpty()) {
                        append("\n\n$memoryBlock")
                    }
                }

                // Last N messages for context (exclude the one we just saved if needed; include all)
                val turns = history.map {
                    ChatTurn(
                        role = if (it.isUser) "user" else "model",
                        content = it.text
                    )
                }

                val result = aiService.chat(
                    messages = turns,
                    systemPrompt = systemPrompt,
                    language = lang
                )

                result.fold(
                    onSuccess = { reply ->
                        repository.saveMessage(convId, reply, isUser = false)
                        _uiState.value = _uiState.value.copy(isLoading = false, error = null)
                    },
                    onFailure = { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = e.message ?: "Unknown error"
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to get response"
                )
            }
        }
    }

    fun retryLast() {
        // Simple retry: re-send the last user message if error exists
        val lastUser = messages.value.lastOrNull { it.isUser } ?: return
        if (_uiState.value.error != null) {
            // Remove nothing; just call send again would duplicate user msg.
            // Better: clear error and call AI again with current history (user msg already saved)
            viewModelScope.launch {
                _uiState.value = _uiState.value.copy(isLoading = true, error = null)
                val convId = _conversationId.value
                val lang = _uiState.value.language
                try {
                    val history = repository.getMessagesOnce(convId)
                    val memories = repository.getAllMemoriesOnce()
                    val memoryBlock = if (memories.isNotEmpty()) {
                        "User long-term memory:\n" + memories.joinToString("\n") { "- ${it.key}: ${it.value}" }
                    } else ""
                    val systemPrompt = "You are ASTRA QUANTUM AI. Creator by Bittu Pandit. Respond in ${if (lang == "hi") "Hindi" else "English"}. $memoryBlock"
                    val turns = history.map {
                        ChatTurn(if (it.isUser) "user" else "model", it.text)
                    }
                    val result = aiService.chat(turns, systemPrompt, lang)
                    result.fold(
                        onSuccess = { reply ->
                            repository.saveMessage(convId, reply, isUser = false)
                            _uiState.value = _uiState.value.copy(isLoading = false)
                        },
                        onFailure = { e ->
                            _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                        }
                    )
                } catch (e: Exception) {
                    _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                }
            }
        }
    }

    fun analyzeImage(bytes: ByteArray, mimeType: String) {
        if (_uiState.value.isLoading) return
        val convId = _conversationId.value
        val lang = _uiState.value.language
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            val prompt = if (lang == "hi") "इस तस्वीर का विस्तार से वर्णन और विश्लेषण करें। जो स्पष्ट नहीं है उसे अनिश्चित बताएं।" else "Describe and analyze this image in detail. State uncertainty where appropriate."
            aiService.analyzeImage(bytes, mimeType, prompt, lang).fold(
                onSuccess = { answer -> repository.saveMessage(convId, "[Image analysis] $answer", isUser = false); _uiState.value = _uiState.value.copy(isLoading = false) },
                onFailure = { e -> _uiState.value = _uiState.value.copy(isLoading = false, error = e.message ?: "Image analysis failed") }
            )
        }
    }

    /** Allow user to store a fact in long-term memory from chat (e.g. via a command or Settings). */
    fun saveToMemory(key: String, value: String) {
        viewModelScope.launch {
            repository.saveMemory(key, value)
        }
    }
}
