package com.bittupandit.astraquantumai

import android.app.Application

class AstraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Future: initialize any offline models or analytics here
    }
}
