package com.bittupandit.astraquantumai.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bittupandit.astraquantumai.ai.GeminiAiService
import com.bittupandit.astraquantumai.ai.ResearchReport
import kotlinx.coroutines.launch

@Composable
fun ResearchScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val service = remember { GeminiAiService() }
    var query by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("hi") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<ResearchReport?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Deep Research", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Creator by Bittu Pandit", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = language == "hi", onClick = { language = "hi" }, label = { Text("हिन्दी") })
            FilterChip(selected = language == "en", onClick = { language = "en" }, label = { Text("English") })
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("क्या शोध करना है? / Research topic") }, minLines = 2)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (query.isNotBlank() && !loading) {
                loading = true; error = null; report = null
                scope.launch {
                    val result = service.research(query.trim(), language)
                    result.onSuccess { report = it }.onFailure { error = it.message ?: "Research failed" }
                    loading = false
                }
            }
        }, enabled = query.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth()) {
            if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else Icon(Icons.Default.Search, contentDescription = null)
            Spacer(Modifier.width(8.dp)); Text(if (language == "hi") "वेब शोध शुरू करें" else "Start web research")
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        report?.let { result ->
            Spacer(Modifier.height(16.dp))
            Text(if (language == "hi") "सारांश" else "Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(result.summary, modifier = Modifier.padding(top = 6.dp))
            result.sections.forEach { section ->
                Spacer(Modifier.height(12.dp)); Text(section.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(section.content, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(if (language == "hi") "स्रोत" else "Sources", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (result.sources.isEmpty()) Text(if (language == "hi") "इस उत्तर में कोई सत्यापित वेब लिंक वापस नहीं आया।" else "No web source links were returned for this answer.")
            result.sources.forEach { source ->
                TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(source.url))) } }) {
                    Text("${source.title}\n${source.url}")
                }
            }
            Text("AI-generated research can contain errors. Open and verify sources before relying on claims.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
