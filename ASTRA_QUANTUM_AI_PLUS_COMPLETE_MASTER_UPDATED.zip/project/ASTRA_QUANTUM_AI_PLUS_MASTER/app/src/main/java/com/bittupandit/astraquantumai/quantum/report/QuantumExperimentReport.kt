package com.bittupandit.astraquantumai.quantum.report

/** Creates a portable plain-text report from simulator or cloud-job results.
 * This is report formatting only; callers are responsible for persisting/exporting the text.
 */
data class QuantumExperimentReport(
    val title: String,
    val algorithm: String,
    val qubitCount: Int,
    val shots: Int,
    val probabilities: Map<String, Double>,
    val notes: String = "",
    val executionMode: String = "CLASSICAL_SIMULATOR"
) {
    init {
        require(title.isNotBlank())
        require(algorithm.isNotBlank())
        require(qubitCount in 1..100)
        require(shots >= 1)
        require(probabilities.values.all { it.isFinite() && it in 0.0..1.0 })
    }

    fun toPlainText(): String = buildString {
        appendLine("ASTRA QUANTUM AI PLUS — EXPERIMENT REPORT")
        appendLine("Creator by Bittu Pandit")
        appendLine("Title: $title")
        appendLine("Algorithm: $algorithm")
        appendLine("Qubits: $qubitCount")
        appendLine("Shots: $shots")
        appendLine("Execution mode: $executionMode")
        appendLine("Probabilities:")
        probabilities.toSortedMap().forEach { (state, probability) ->
            appendLine("  |$state>: ${(probability * 100.0).formatPercent()}%")
        }
        if (notes.isNotBlank()) appendLine("Notes: $notes")
        appendLine("\nScientific note: simulator results are classical calculations, not measurements from physical quantum hardware.")
    }

    private fun Double.formatPercent(): String = String.format(java.util.Locale.US, "%.4f", this)
}
