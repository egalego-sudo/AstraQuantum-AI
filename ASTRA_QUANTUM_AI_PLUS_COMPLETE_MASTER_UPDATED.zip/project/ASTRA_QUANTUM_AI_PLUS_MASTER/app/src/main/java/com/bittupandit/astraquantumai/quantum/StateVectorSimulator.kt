package com.bittupandit.astraquantumai.quantum

import kotlin.math.*

/**
 * Proper multi-qubit state-vector simulator.
 * State is a vector of 2^n complex amplitudes.
 * Supports entanglement via CNOT and other two-qubit operations.
 * This is classical simulation only – not real quantum hardware.
 */
class StateVectorSimulator(val numQubits: Int) {
    private val size: Int
    private var state: Array<Complex>

    init {
        require(numQubits in 1..8) { "Educational limit: 1-8 qubits (state size 2^n)" }
        size = 1 shl numQubits
        state = Array(size) { Complex(0.0) }
        // Start in |00...0⟩
        state[0] = Complex(1.0)
    }

    fun reset() {
        state = Array(size) { Complex(0.0) }
        state[0] = Complex(1.0)
    }

    fun getAmplitudes(): List<Complex> = state.toList()

    fun probability(bitstring: Int): Double {
        require(bitstring in 0 until size)
        return state[bitstring].magnitudeSquared()
    }

    fun probabilities(): DoubleArray {
        return DoubleArray(size) { state[it].magnitudeSquared() }
    }

    /** Apply single-qubit gate matrix [[a,b],[c,d]] to qubit q */
    fun applySingleQubitGate(q: Int, a: Complex, b: Complex, c: Complex, d: Complex) {
        require(q in 0 until numQubits)
        val newState = Array(size) { Complex(0.0) }
        val mask = 1 shl q
        for (i in 0 until size step (mask * 2)) {
            for (j in 0 until mask) {
                val i0 = i + j
                val i1 = i0 + mask
                val amp0 = state[i0]
                val amp1 = state[i1]
                newState[i0] = a * amp0 + b * amp1
                newState[i1] = c * amp0 + d * amp1
            }
        }
        state = newState
        normalize()
    }

    fun hadamard(q: Int) {
        val s = 1.0 / sqrt(2.0)
        applySingleQubitGate(q,
            Complex(s), Complex(s),
            Complex(s), Complex(-s)
        )
    }

    fun pauliX(q: Int) {
        applySingleQubitGate(q,
            Complex(0.0), Complex(1.0),
            Complex(1.0), Complex(0.0)
        )
    }

    fun pauliY(q: Int) {
        applySingleQubitGate(q,
            Complex(0.0), Complex(0.0, -1.0),
            Complex(0.0, 1.0), Complex(0.0)
        )
    }

    fun pauliZ(q: Int) {
        applySingleQubitGate(q,
            Complex(1.0), Complex(0.0),
            Complex(0.0), Complex(-1.0)
        )
    }

    /** Controlled-NOT: control qubit c, target qubit t. Creates entanglement. */
    fun cnot(control: Int, target: Int) {
        require(control in 0 until numQubits && target in 0 until numQubits && control != target)
        val newState = Array(size) { Complex(0.0) }
        val cMask = 1 shl control
        val tMask = 1 shl target
        for (i in 0 until size) {
            if ((i and cMask) != 0) {
                // control is |1⟩ → flip target bit
                val flipped = i xor tMask
                newState[flipped] = state[i]
            } else {
                newState[i] = state[i]
            }
        }
        state = newState
    }

    /** Grover phase oracle followed by inversion-about-the-mean diffusion. */
    fun groverSearch(markedIndex: Int): Int {
        require(markedIndex in 0 until size) { "Marked state must be between 0 and ${size - 1}" }
        // Uniform superposition is prepared by the caller.
        state[markedIndex] = Complex(-state[markedIndex].real, -state[markedIndex].imag)
        val meanReal = state.map { it.real }.average()
        val meanImag = state.map { it.imag }.average()
        for (i in state.indices) {
            state[i] = Complex(2.0 * meanReal - state[i].real, 2.0 * meanImag - state[i].imag)
        }
        normalize()
        return markedIndex
    }

    fun measureAll(): Int {
        val probs = probabilities()
        var r = Math.random()
        var cumulative = 0.0
        var outcome = 0
        for (i in probs.indices) {
            cumulative += probs[i]
            if (r < cumulative) {
                outcome = i
                break
            }
        }
        // Collapse
        state = Array(size) { Complex(0.0) }
        state[outcome] = Complex(1.0)
        return outcome
    }

    fun measureQubit(q: Int): Int {
        var p1 = 0.0
        val mask = 1 shl q
        for (i in 0 until size) {
            if ((i and mask) != 0) p1 += state[i].magnitudeSquared()
        }
        val result = if (Math.random() < p1) 1 else 0
        // Collapse
        val newState = Array(size) { Complex(0.0) }
        var norm = 0.0
        for (i in 0 until size) {
            val bit = if ((i and mask) != 0) 1 else 0
            if (bit == result) {
                newState[i] = state[i]
                norm += state[i].magnitudeSquared()
            }
        }
        norm = sqrt(norm)
        if (norm > 1e-12) {
            for (i in 0 until size) {
                newState[i] = Complex(newState[i].real / norm, newState[i].imag / norm)
            }
        }
        state = newState
        return result
    }

    private fun normalize() {
        var norm = 0.0
        for (c in state) norm += c.magnitudeSquared()
        norm = sqrt(norm)
        if (norm > 1e-12) {
            for (i in state.indices) {
                state[i] = Complex(state[i].real / norm, state[i].imag / norm)
            }
        }
    }

    fun stateDescription(): String {
        val sb = StringBuilder()
        for (i in 0 until size) {
            val amp = state[i]
            if (amp.magnitudeSquared() > 1e-8) {
                if (sb.isNotEmpty()) sb.append(" + ")
                val bits = Integer.toBinaryString(i).padStart(numQubits, '0')
                sb.append("(${amp})|$bits⟩")
            }
        }
        return if (sb.isEmpty()) "0" else sb.toString()
    }

    fun qubitMarginalProbabilities(): List<Pair<Double, Double>> {
        return (0 until numQubits).map { q ->
            var p1 = 0.0
            val mask = 1 shl q
            for (i in 0 until size) {
                if ((i and mask) != 0) p1 += state[i].magnitudeSquared()
            }
            (1.0 - p1) to p1
        }
    }
}
