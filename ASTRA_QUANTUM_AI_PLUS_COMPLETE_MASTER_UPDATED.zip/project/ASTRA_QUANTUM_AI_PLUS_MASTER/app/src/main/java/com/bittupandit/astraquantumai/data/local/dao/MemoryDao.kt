package com.bittupandit.astraquantumai.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.bittupandit.astraquantumai.data.local.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM long_term_memory ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM long_term_memory ORDER BY updatedAt DESC")
    suspend fun getAllOnce(): List<MemoryEntity>

    @Query("SELECT * FROM long_term_memory WHERE `key` = :key LIMIT 1")
    suspend fun getByKey(key: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(memory: MemoryEntity): Long

    @Query("DELETE FROM long_term_memory WHERE `key` = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM long_term_memory")
    suspend fun clearAll()
}
