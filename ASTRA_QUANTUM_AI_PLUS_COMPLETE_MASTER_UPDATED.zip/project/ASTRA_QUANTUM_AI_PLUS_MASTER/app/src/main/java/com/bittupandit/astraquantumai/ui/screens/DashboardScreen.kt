package com.bittupandit.astraquantumai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.ui.navigation.Screen
import com.bittupandit.astraquantumai.ui.theme.QuantumAccent

@Composable
fun DashboardScreen(navController: NavController) {
    val cards = listOf(
        DashCard("AI Chat", "Intelligent assistant with memory", Icons.Default.Chat, Screen.Chat.route),
        DashCard("Quantum Lab", "Simulate qubits & gates", Icons.Default.Science, Screen.Quantum.route),
        DashCard("Projects", "Personal AI workspace", Icons.Default.Folder, Screen.Projects.route),
        DashCard("Deep Research", "Evidence, web sources & analysis", Icons.Default.Search, Screen.Research.route),
        DashCard("Settings", "Theme, language, privacy", Icons.Default.Settings, Screen.Settings.route)
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp))
        ) {
            Image(
                painter = painterResource(R.drawable.astra_quantum_hero),
                contentDescription = "ASTRA Quantum cosmic quantum AI theme",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(listOf(Color(0xDD071126), Color(0x553D1A78), Color(0x99071325)))
                )
            )
            Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                Text("ASTRA QUANTUM AI PLUS", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Advanced Scientific Thinking & Reasoning Architecture",
                    style = MaterialTheme.typography.bodySmall, color = Color(0xFFE2E8FF))
                Spacer(Modifier.height(5.dp))
                Text(stringResource(R.string.creator_credit), style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFF70F4E2), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Explore your quantum universe", style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(cards) { card ->
                ElevatedCard(
                    onClick = { navController.navigate(card.route) },
                    modifier = Modifier.fillMaxWidth().height(132.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(15.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.Start
                    ) {
                        Icon(card.icon, contentDescription = null, tint = QuantumAccent)
                        Spacer(Modifier.height(8.dp))
                        Text(card.title, fontWeight = FontWeight.Bold)
                        Text(card.subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                }
            }
        }
    }
}

private data class DashCard(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String
)
