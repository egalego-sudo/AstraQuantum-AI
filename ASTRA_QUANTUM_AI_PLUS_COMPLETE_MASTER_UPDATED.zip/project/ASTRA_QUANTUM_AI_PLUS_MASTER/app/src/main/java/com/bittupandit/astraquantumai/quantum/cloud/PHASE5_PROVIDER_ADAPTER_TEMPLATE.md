# Phase 5 — Quantum cloud adapter integration

The app currently contains a provider-neutral `QuantumCloudProvider` contract. No live hardware provider is connected in this package.

To activate a real provider, a backend service must: authenticate using server-side secrets; validate circuits; translate supported gates to the provider's documented API; submit jobs; poll job status; normalize counts; and return results to the Android app. Never put provider tokens in the APK or source control.

Required before live use: choose a provider and account, obtain API credentials, deploy a secured backend, implement its adapter, and run provider-specific integration tests. Until then, use the local classical simulator and label it accurately.
