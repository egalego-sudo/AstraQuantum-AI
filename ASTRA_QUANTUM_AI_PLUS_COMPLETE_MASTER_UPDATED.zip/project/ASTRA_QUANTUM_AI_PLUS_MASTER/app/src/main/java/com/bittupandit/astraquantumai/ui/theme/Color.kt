package com.bittupandit.astraquantumai.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic dark palette
val QuantumBlue = Color(0xFF00E5FF)
val QuantumPurple = Color(0xFF7C4DFF)
val QuantumDark = Color(0xFF0A0E17)
val QuantumSurface = Color(0xFF121826)
val QuantumCard = Color(0xFF1A2233)
val QuantumAccent = Color(0xFF00FFC6)
val QuantumError = Color(0xFFFF5252)

// Light palette
val LightPrimary = Color(0xFF0066CC)
val LightSecondary = Color(0xFF5C00CC)
val LightBackground = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1A1A2E)
