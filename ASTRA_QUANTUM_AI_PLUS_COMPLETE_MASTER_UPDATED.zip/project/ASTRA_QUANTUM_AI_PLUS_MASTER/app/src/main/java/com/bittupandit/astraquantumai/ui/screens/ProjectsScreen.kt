package com.bittupandit.astraquantumai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.data.local.entity.ProjectEntity
import com.bittupandit.astraquantumai.data.repository.AstraRepository
import com.bittupandit.astraquantumai.ui.theme.QuantumAccent
import kotlinx.coroutines.launch

@Composable
fun ProjectsScreen() {
    val context = LocalContext.current
    val repository = remember { AstraRepository(context) }
    val scope = rememberCoroutineScope()
    val projects by repository.getAllProjects().collectAsState(initial = emptyList())
    var showDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<ProjectEntity?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.projects), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.creator_credit), style = MaterialTheme.typography.bodyMedium, color = QuantumAccent)
            }
            FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Default.Add, contentDescription = stringResource(R.string.new_project)) }
        }
        Spacer(Modifier.height(16.dp))
        if (projects.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (stringResource(R.string.projects).isNotBlank()) "अभी कोई प्रोजेक्ट नहीं है। + दबाकर बनाएँ।" else "No projects yet. Tap + to create one.")
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects, key = { it.id }) { project ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(project.name, fontWeight = FontWeight.Bold)
                            if (project.description.isNotBlank()) Text(project.description, style = MaterialTheme.typography.bodyMedium)
                            Text("Updated ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { deleteTarget = project }) { Icon(Icons.Default.Delete, contentDescription = "Delete project") }
                    }
                }
            }
        }
    }
    if (showDialog) AlertDialog(
        onDismissRequest = { showDialog = false }, title = { Text("New project") },
        text = { Column {
            OutlinedTextField(newName, { newName = it }, label = { Text("Project name") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(description, { description = it }, label = { Text("Description") }, minLines = 2)
        } },
        confirmButton = { TextButton(onClick = { if (newName.isNotBlank()) scope.launch {
            repository.addProject(newName.trim(), description.trim()); newName = ""; description = ""; showDialog = false
        } }) { Text("Create") } },
        dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
    )
    deleteTarget?.let { target -> AlertDialog(
        onDismissRequest = { deleteTarget = null }, title = { Text("Delete project?") },
        text = { Text("${target.name} will be deleted from this device.") },
        confirmButton = { TextButton(onClick = { scope.launch { repository.deleteProject(target.id); deleteTarget = null } }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
    ) }
}
