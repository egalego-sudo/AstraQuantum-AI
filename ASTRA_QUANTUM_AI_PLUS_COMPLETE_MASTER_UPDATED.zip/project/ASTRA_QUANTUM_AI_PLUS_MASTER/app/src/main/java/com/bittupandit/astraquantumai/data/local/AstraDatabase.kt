package com.bittupandit.astraquantumai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.bittupandit.astraquantumai.data.local.dao.ChatDao
import com.bittupandit.astraquantumai.data.local.dao.MemoryDao
import com.bittupandit.astraquantumai.data.local.dao.ProjectDao
import com.bittupandit.astraquantumai.data.local.entity.ChatMessageEntity
import com.bittupandit.astraquantumai.data.local.entity.MemoryEntity
import com.bittupandit.astraquantumai.data.local.entity.ProjectEntity

@Database(
    entities = [
        ChatMessageEntity::class,
        ProjectEntity::class,
        MemoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AstraDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun projectDao(): ProjectDao
    abstract fun memoryDao(): MemoryDao

    companion object {
        @Volatile
        private var INSTANCE: AstraDatabase? = null

        fun getInstance(context: Context): AstraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AstraDatabase::class.java,
                    "astra_quantum_ai.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
