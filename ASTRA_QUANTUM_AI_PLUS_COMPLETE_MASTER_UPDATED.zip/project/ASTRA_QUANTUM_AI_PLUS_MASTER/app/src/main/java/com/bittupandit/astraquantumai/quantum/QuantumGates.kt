package com.bittupandit.astraquantumai.quantum

import kotlin.math.sqrt

/**
 * Standard single-qubit and two-qubit gates.
 * All operations are classical matrix multiplications on the state vector.
 */
object QuantumGates {

    // Hadamard: creates superposition
    fun hadamard(q: Qubit) {
        val a = q.alpha
        val b = q.beta
        val invSqrt2 = 1.0 / sqrt(2.0)
        q.alpha = (a + b) * invSqrt2
        q.beta = (a + (b * -1.0)) * invSqrt2   // a - b
        q.normalize()
    }

    // Pauli-X (NOT gate)
    fun pauliX(q: Qubit) {
        val temp = q.alpha
        q.alpha = q.beta
        q.beta = temp
    }

    // Pauli-Y
    fun pauliY(q: Qubit) {
        val a = q.alpha
        val b = q.beta
        // Y = [[0, -i], [i, 0]]
        q.alpha = Complex(b.imag, -b.real)   // -i * b
        q.beta = Complex(-a.imag, a.real)    // i * a
        q.normalize()
    }

    // Pauli-Z
    fun pauliZ(q: Qubit) {
        q.beta = q.beta * -1.0
    }

    // Phase gate S (√Z)
    fun phaseS(q: Qubit) {
        // Multiplies |1⟩ by i
        q.beta = Complex(-q.beta.imag, q.beta.real)
    }

    // T gate
    fun phaseT(q: Qubit) {
        // Multiplies |1⟩ by e^{iπ/4}
        val angle = Math.PI / 4
        val cos = kotlin.math.cos(angle)
        val sin = kotlin.math.sin(angle)
        val b = q.beta
        q.beta = Complex(b.real * cos - b.imag * sin, b.real * sin + b.imag * cos)
    }

    /**
     * CNOT gate on two qubits.
     * control and target are indices in a list of qubits.
     * This is a simplified two-qubit operation for educational simulation.
     */
    fun cnot(qubits: MutableList<Qubit>, control: Int, target: Int) {
        require(control in qubits.indices && target in qubits.indices)
        // Simplified educational version: if control is |1⟩ with high probability, flip target
        // For a more accurate multi-qubit state we would need a full 2^n state vector.
        // This implementation uses a probabilistic teaching approach for 1-2 qubits.
        val controlQ = qubits[control]
        val targetQ = qubits[target]

        // If control is clearly in |1⟩, apply X to target
        if (controlQ.probabilityOne() > 0.9) {
            pauliX(targetQ)
        } else if (controlQ.probabilityZero() > 0.9) {
            // do nothing
        } else {
            // Superposition case – for teaching we apply a partial flip weighted by probability
            // (Full entangled state vector is more complex; this keeps the module educational and light)
            val p1 = controlQ.probabilityOne()
            if (Math.random() < p1) {
                pauliX(targetQ)
            }
        }
    }
}
