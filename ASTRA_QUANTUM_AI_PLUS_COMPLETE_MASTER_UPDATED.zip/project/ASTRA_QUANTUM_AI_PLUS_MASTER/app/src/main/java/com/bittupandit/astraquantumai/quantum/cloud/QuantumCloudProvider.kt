package com.bittupandit.astraquantumai.quantum.cloud

/** Provider-neutral contract. Implementations must submit jobs only to documented provider APIs. */
interface QuantumCloudProvider {
    val providerName: String
    suspend fun getBackends(): Result<List<QuantumBackend>>
    suspend fun submit(circuit: CloudCircuitRequest, backendId: String): Result<QuantumJob>
    suspend fun getJob(jobId: String): Result<QuantumJob>
}

data class QuantumBackend(
    val id: String,
    val name: String,
    val qubitCount: Int,
    val operational: Boolean
)

data class CloudCircuitRequest(
    val qubitCount: Int,
    val operations: List<CloudGateOperation>,
    val shots: Int = 1024
) {
    init {
        require(qubitCount in 1..100)
        require(shots in 1..100000)
        require(operations.all { it.control in 0 until qubitCount && it.target in 0 until qubitCount })
    }
}

data class CloudGateOperation(val gate: String, val control: Int, val target: Int)

enum class QuantumJobStatus { QUEUED, RUNNING, COMPLETED, FAILED, UNKNOWN }

data class QuantumJob(
    val id: String,
    val backendId: String,
    val status: QuantumJobStatus,
    val counts: Map<String, Int> = emptyMap(),
    val message: String? = null
)
