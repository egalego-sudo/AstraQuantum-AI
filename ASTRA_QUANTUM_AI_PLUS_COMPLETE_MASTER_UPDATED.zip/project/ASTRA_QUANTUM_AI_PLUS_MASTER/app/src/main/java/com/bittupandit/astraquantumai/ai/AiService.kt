package com.bittupandit.astraquantumai.ai

/**
 * Abstraction for the AI backend.
 * Implementations must never hard-code API keys.
 * Key is supplied at runtime from BuildConfig / secure storage / user input.
 */
interface AiService {
    suspend fun chat(
        messages: List<ChatTurn>,
        systemPrompt: String? = null,
        language: String = "en"
    ): Result<String>

    suspend fun research(query: String, language: String = "en"): Result<ResearchReport>

    suspend fun analyzeImage(
        imageBytes: ByteArray, mimeType: String, prompt: String, language: String = "en"
    ): Result<String>
}

data class ChatTurn(
    val role: String, // "user" or "model"
    val content: String
)

data class ResearchReport(
    val summary: String,
    val sections: List<ResearchSection>,
    val sources: List<SourceLink>
)

data class ResearchSection(
    val title: String,
    val content: String
)

data class SourceLink(
    val title: String,
    val url: String,
    val snippet: String? = null
)
