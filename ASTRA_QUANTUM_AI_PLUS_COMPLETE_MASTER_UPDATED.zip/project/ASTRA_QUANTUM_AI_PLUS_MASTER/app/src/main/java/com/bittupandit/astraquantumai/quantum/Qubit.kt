package com.bittupandit.astraquantumai.quantum

import kotlin.math.*

/**
 * Classical simulation of a single qubit.
 * State is represented as α|0⟩ + β|1⟩ where α and β are complex numbers.
 * This is pure classical linear algebra – not real quantum hardware.
 */
data class Complex(val real: Double, val imag: Double = 0.0) {
    operator fun plus(other: Complex) = Complex(real + other.real, imag + other.imag)
    operator fun times(other: Complex) = Complex(
        real * other.real - imag * other.imag,
        real * other.imag + imag * other.real
    )
    operator fun times(scalar: Double) = Complex(real * scalar, imag * scalar)
    fun magnitudeSquared() = real * real + imag * imag
    fun conjugate() = Complex(real, -imag)
    override fun toString(): String {
        return when {
            imag == 0.0 -> "%.4f".format(real)
            real == 0.0 -> "%.4fi".format(imag)
            imag > 0 -> "%.4f + %.4fi".format(real, imag)
            else -> "%.4f - %.4fi".format(real, -imag)
        }
    }
}

class Qubit(var alpha: Complex = Complex(1.0), var beta: Complex = Complex(0.0)) {

    fun normalize() {
        val norm = sqrt(alpha.magnitudeSquared() + beta.magnitudeSquared())
        if (norm > 1e-12) {
            alpha = Complex(alpha.real / norm, alpha.imag / norm)
            beta = Complex(beta.real / norm, beta.imag / norm)
        }
    }

    fun probabilityZero(): Double = alpha.magnitudeSquared()
    fun probabilityOne(): Double = beta.magnitudeSquared()

    fun measure(): Int {
        val p0 = probabilityZero()
        return if (Math.random() < p0) {
            // Collapse to |0⟩
            alpha = Complex(1.0)
            beta = Complex(0.0)
            0
        } else {
            // Collapse to |1⟩
            alpha = Complex(0.0)
            beta = Complex(1.0)
            1
        }
    }

    fun stateString(): String {
        return "${alpha}|0⟩ + ${beta}|1⟩"
    }

    fun copy(): Qubit = Qubit(alpha.copy(), beta.copy())
}

// Extension for Complex copy
fun Complex.copy() = Complex(this.real, this.imag)
