package com.bittupandit.astraquantumai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.data.repository.AstraRepository
import com.bittupandit.astraquantumai.data.local.entity.MemoryEntity
import com.bittupandit.astraquantumai.ui.theme.QuantumAccent
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    darkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val repository = remember { AstraRepository(context) }
    val scope = rememberCoroutineScope()
    var language by remember { mutableStateOf("en") }
    var showClearChats by remember { mutableStateOf(false) }
    var showClearMemory by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    val memories by repository.getAllMemories().collectAsState(initial = emptyList())
    var showAddMemory by remember { mutableStateOf(false) }
    var memoryKey by remember { mutableStateOf("") }
    var memoryValue by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.settings),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = stringResource(R.string.creator_credit),
            style = MaterialTheme.typography.bodyMedium,
            color = QuantumAccent
        )

        Spacer(Modifier.height(24.dp))

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(R.string.dark_theme))
                Switch(checked = darkTheme, onCheckedChange = onThemeChange)
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.language), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = language == "en",
                        onClick = { language = "en" },
                        label = { Text(stringResource(R.string.english)) }
                    )
                    FilterChip(
                        selected = language == "hi",
                        onClick = { language = "hi" },
                        label = { Text(stringResource(R.string.hindi)) }
                    )
                }
                Text(
                    text = "Chat language is controlled inside the AI Chat screen (EN / हिं). Full app locale can be added later.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.privacy), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { showClearChats = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear all chat history")
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { showClearMemory = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(stringResource(R.string.clear_memory))
                }
                statusMessage?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }


        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Long-term memory", fontWeight = FontWeight.SemiBold)
                Text("ये तथ्य आपके डिवाइस पर सेव होंगे और AI के जवाब में संदर्भ के रूप में उपयोग होंगे।", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { showAddMemory = true }) { Text("Add memory") }
                memories.forEach { item ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(item.key, fontWeight = FontWeight.Medium); Text(item.value, style = MaterialTheme.typography.bodySmall) }
                        TextButton(onClick = { scope.launch { repository.deleteMemory(item.key) } }) { Text("Delete") }
                    }
                }
                if (memories.isEmpty()) Text("No saved memories.", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("AI Configuration", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Set AI_BACKEND_URL in local.properties to your deployed secure HTTPS backend. Keep provider keys on the server.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }

    if (showAddMemory) AlertDialog(
        onDismissRequest = { showAddMemory = false }, title = { Text("Add memory") },
        text = { Column {
            OutlinedTextField(memoryKey, { memoryKey = it }, label = { Text("Title / key") }, singleLine = true)
            OutlinedTextField(memoryValue, { memoryValue = it }, label = { Text("Fact / value") }, minLines = 2)
        } },
        confirmButton = { TextButton(onClick = { if (memoryKey.isNotBlank() && memoryValue.isNotBlank()) scope.launch {
            repository.saveMemory(memoryKey.trim(), memoryValue.trim()); memoryKey = ""; memoryValue = ""; showAddMemory = false
        } }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showAddMemory = false }) { Text("Cancel") } }
    )

    if (showClearChats) {
        AlertDialog(
            onDismissRequest = { showClearChats = false },
            title = { Text("Clear all chats?") },
            text = { Text("Every conversation and message will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        repository.clearAllChats()
                        statusMessage = "All chat history cleared."
                        showClearChats = false
                    }
                }) { Text("Clear") }
            },
            dismissButton = {
                TextButton(onClick = { showClearChats = false }) { Text("Cancel") }
            }
        )
    }

    if (showClearMemory) {
        AlertDialog(
            onDismissRequest = { showClearMemory = false },
            title = { Text("Clear long-term memory?") },
            text = { Text("All saved memory facts used by the AI will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        repository.clearAllMemory()
                        statusMessage = "Long-term memory cleared."
                        showClearMemory = false
                    }
                }) { Text("Clear") }
            },
            dismissButton = {
                TextButton(onClick = { showClearMemory = false }) { Text("Cancel") }
            }
        )
    }
}
