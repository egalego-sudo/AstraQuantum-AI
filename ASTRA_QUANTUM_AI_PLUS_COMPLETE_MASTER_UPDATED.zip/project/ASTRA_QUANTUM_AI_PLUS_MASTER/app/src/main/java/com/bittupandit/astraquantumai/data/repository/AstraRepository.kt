package com.bittupandit.astraquantumai.data.repository

import android.content.Context
import com.bittupandit.astraquantumai.data.local.AstraDatabase
import com.bittupandit.astraquantumai.data.local.entity.ChatMessageEntity
import com.bittupandit.astraquantumai.data.local.entity.MemoryEntity
import com.bittupandit.astraquantumai.data.local.entity.ProjectEntity
import kotlinx.coroutines.flow.Flow

class AstraRepository(context: Context) {
    private val db = AstraDatabase.getInstance(context)
    private val chatDao = db.chatDao()
    private val projectDao = db.projectDao()
    private val memoryDao = db.memoryDao()

    // Chat
    fun getMessages(conversationId: String): Flow<List<ChatMessageEntity>> =
        chatDao.getMessages(conversationId)

    suspend fun getMessagesOnce(conversationId: String): List<ChatMessageEntity> =
        chatDao.getMessagesOnce(conversationId)

    fun getConversationIds(): Flow<List<String>> = chatDao.getConversationIds()

    suspend fun saveMessage(conversationId: String, text: String, isUser: Boolean) {
        chatDao.insert(
            ChatMessageEntity(
                conversationId = conversationId,
                text = text,
                isUser = isUser
            )
        )
    }

    suspend fun clearConversation(conversationId: String) =
        chatDao.clearConversation(conversationId)

    suspend fun clearAllChats() = chatDao.clearAll()

    // Projects
    fun getAllProjects(): Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun addProject(name: String, description: String = ""): Long {
        return projectDao.insert(ProjectEntity(name = name, description = description))
    }

    suspend fun deleteProject(id: Long) = projectDao.delete(id)

    // Long-term memory
    fun getAllMemories(): Flow<List<MemoryEntity>> = memoryDao.getAll()

    suspend fun getAllMemoriesOnce(): List<MemoryEntity> = memoryDao.getAllOnce()

    suspend fun saveMemory(key: String, value: String) {
        memoryDao.deleteByKey(key)
        memoryDao.insert(
            MemoryEntity(
                key = key,
                value = value,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getMemory(key: String): String? = memoryDao.getByKey(key)?.value

    suspend fun deleteMemory(key: String) = memoryDao.deleteByKey(key)

    suspend fun clearAllMemory() = memoryDao.clearAll()
}
