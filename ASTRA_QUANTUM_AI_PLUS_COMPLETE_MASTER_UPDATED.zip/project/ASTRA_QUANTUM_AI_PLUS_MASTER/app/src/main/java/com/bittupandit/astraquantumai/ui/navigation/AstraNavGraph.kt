package com.bittupandit.astraquantumai.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.ui.screens.*

sealed class Screen(val route: String, val titleRes: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : Screen("dashboard", R.string.dashboard, Icons.Default.Dashboard)
    object Chat : Screen("chat", R.string.ai_chat, Icons.Default.Chat)
    object Quantum : Screen("quantum", R.string.quantum_lab, Icons.Default.Science)
    object Projects : Screen("projects", R.string.projects, Icons.Default.Folder)
    object Research : Screen("research", R.string.research, Icons.Default.Search)
    object Settings : Screen("settings", R.string.settings, Icons.Default.Settings)
}

@Composable
fun AstraNavGraph(
    darkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val items = listOf(Screen.Dashboard, Screen.Chat, Screen.Research, Screen.Quantum, Screen.Projects, Screen.Settings)

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = null) },
                        label = { Text(stringResource(screen.titleRes)) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) { DashboardScreen(navController) }
            composable(Screen.Chat.route) { ChatScreen() }
            composable(Screen.Research.route) { ResearchScreen() }
            composable(Screen.Quantum.route) { QuantumLabScreen() }
            composable(Screen.Projects.route) { ProjectsScreen() }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    darkTheme = darkTheme,
                    onThemeChange = onThemeChange
                )
            }
        }
    }
}
