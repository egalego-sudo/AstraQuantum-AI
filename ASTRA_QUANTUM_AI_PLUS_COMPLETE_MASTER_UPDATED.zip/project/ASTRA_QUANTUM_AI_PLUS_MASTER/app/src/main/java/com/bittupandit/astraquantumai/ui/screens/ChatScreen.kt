package com.bittupandit.astraquantumai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Image
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.DisposableEffect
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Locale
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.data.local.entity.ChatMessageEntity
import com.bittupandit.astraquantumai.ui.theme.QuantumAccent
import com.bittupandit.astraquantumai.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel = viewModel()
) {
    val messages by viewModel.messages.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val conversations by viewModel.conversations.collectAsState()
    val context = LocalContext.current
    val tts = remember(context) { TextToSpeech(context) { _ -> } }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = (input + " " + spoken).trim()
    }
    val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val mime = context.contentResolver.getType(uri).orEmpty()
                    if (mime == "application/pdf") {
                        PDFBoxResourceLoader.init(context.applicationContext)
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            PDDocument.load(stream).use { PDFTextStripper().getText(it).take(80000) }
                        }
                    } else {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(80000) }
                    }
                }
            }.onSuccess { content ->
                if (!content.isNullOrBlank()) input = (input + "\n\n[Imported document text]\n" + content).trim()
                else viewModel.showExternalError("इस PDF में selectable text नहीं मिला। Scanned PDF के लिए OCR सुविधा अभी बाकी है।")
            }.onFailure { viewModel.showExternalError("Document पढ़ा नहीं जा सका: ${it.message}") }
        }
    }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { it.readBytes() } }
            }.onSuccess { bytes ->
                if (bytes != null && bytes.isNotEmpty() && bytes.size <= 12 * 1024 * 1024) {
                    viewModel.analyzeImage(bytes, context.contentResolver.getType(uri) ?: "image/jpeg")
                } else viewModel.showExternalError("Image खाली है या 12 MB से बड़ी है।")
            }.onFailure { viewModel.showExternalError("Image पढ़ी नहीं जा सकी: ${it.message}") }
        }
    }

    // Auto-scroll when messages change
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Top bar
        Surface(tonalElevation = 2.dp) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.ai_chat),
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = stringResource(R.string.creator_credit),
                        style = MaterialTheme.typography.bodySmall,
                        color = QuantumAccent
                    )
                }
                // Language toggle
                FilterChip(
                    selected = uiState.language == "en",
                    onClick = { viewModel.setLanguage("en") },
                    label = { Text("EN") }
                )
                Spacer(Modifier.width(4.dp))
                FilterChip(
                    selected = uiState.language == "hi",
                    onClick = { viewModel.setLanguage("hi") },
                    label = { Text("हिं") }
                )
                IconButton(onClick = { showHistory = true }) {
                    Icon(Icons.Default.History, contentDescription = "Chat history")
                }
                IconButton(onClick = { viewModel.newChat() }) {
                    Icon(Icons.Default.Add, contentDescription = "New Chat")
                }
                IconButton(onClick = { showDeleteConfirm = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Chat")
                }
            }
        }

        // Messages
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            if (messages.isEmpty() && !uiState.isLoading) {
                item {
                    Text(
                        text = if (uiState.language == "hi")
                            "नमस्ते! मैं ASTRA QUANTUM AI हूँ। कुछ भी पूछें।\n(Creator by Bittu Pandit)\n\nनोट: असली जवाब के लिए सुरक्षित AI backend deploy करके AI_BACKEND_URL सेट करें।"
                        else
                            "Hello! I am ASTRA QUANTUM AI. Ask me anything.\n(Creator by Bittu Pandit)\n\nNote: Deploy the secure AI backend and set AI_BACKEND_URL for real replies.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
            items(messages, key = { it.id }) { msg ->
                MessageBubble(msg, onSpeak = if (!msg.isUser) ({
                    tts.language = if (uiState.language == "hi") Locale.forLanguageTag("hi-IN") else Locale.US
                    tts.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, "astra-${msg.id}")
                }) else null)
            }
            if (uiState.isLoading) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (uiState.language == "hi") "सोच रहा हूँ…" else "Thinking…",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        // Error + Retry
        uiState.error?.let { err ->
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = err,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = { viewModel.retryLast() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Retry")
                    }
                    TextButton(onClick = { viewModel.clearError() }) {
                        Text("Dismiss")
                    }
                }
            }
        }

        // Input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        if (uiState.language == "hi") "संदेश लिखें…"
                        else stringResource(R.string.type_message)
                    )
                },
                shape = RoundedCornerShape(24.dp),
                maxLines = 4,
                enabled = !uiState.isLoading
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (uiState.language == "hi") "hi-IN" else "en-US")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, if (uiState.language == "hi") "बोलिए" else "Speak now")
                }
                runCatching { speechLauncher.launch(intent) }.onFailure { viewModel.showExternalError("Speech input उपलब्ध नहीं है।") }
            }) { Icon(Icons.Default.Mic, contentDescription = "Voice input") }
            IconButton(onClick = { documentLauncher.launch(arrayOf("text/plain", "text/markdown", "application/pdf")) }) {
                Icon(Icons.Default.AttachFile, contentDescription = "Import TXT, Markdown or PDF")
            }
            IconButton(onClick = { imageLauncher.launch("image/*") }, enabled = !uiState.isLoading) {
                Icon(Icons.Default.Image, contentDescription = "Analyze image")
            }
            FilledIconButton(
                onClick = {
                    val t = input.trim()
                    if (t.isNotEmpty()) {
                        viewModel.sendMessage(t)
                        input = ""
                    }
                },
                enabled = input.isNotBlank() && !uiState.isLoading
            ) {
                Icon(Icons.Default.Send, contentDescription = stringResource(R.string.send))
            }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text(if (uiState.language == "hi") "पुरानी बातचीत" else "Chat history") },
            text = {
                if (conversations.isEmpty()) Text(if (uiState.language == "hi") "अभी कोई पुरानी बातचीत नहीं है।" else "No saved conversations yet.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(conversations.reversed()) { id ->
                        TextButton(onClick = { viewModel.openConversation(id); showHistory = false }) {
                            Text(id.take(8) + "…  •  " + id)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(if (uiState.language == "hi") "चैट हटाएँ?" else "Delete chat?") },
            text = {
                Text(
                    if (uiState.language == "hi")
                        "इस बातचीत के सभी संदेश हट जाएँगे।"
                    else
                        "All messages in this conversation will be deleted."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteCurrentChat()
                    showDeleteConfirm = false
                }) { Text(if (uiState.language == "hi") "हटाएँ" else "Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(if (uiState.language == "hi") "रद्द" else "Cancel")
                }
            }
        )
    }
}

@Composable
private fun MessageBubble(msg: ChatMessageEntity, onSpeak: (() -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (msg.isUser)
                    MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant
            ),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (msg.isUser) 16.dp else 4.dp,
                bottomEnd = if (msg.isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(text = msg.text, style = MaterialTheme.typography.bodyMedium)
                if (onSpeak != null) {
                    TextButton(onClick = onSpeak, contentPadding = PaddingValues(top = 4.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Speak reply", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Listen")
                    }
                }
            }
        }
    }
}
