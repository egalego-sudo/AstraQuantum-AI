package com.bittupandit.astraquantumai.ai

import com.bittupandit.astraquantumai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Calls the ASTRA backend. Provider API keys never belong in the Android application. */
class GeminiAiService : AiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val model = BuildConfig.AI_MODEL.ifBlank { "gemini-2.5-flash" }
    private val backendUrl = BuildConfig.AI_BACKEND_URL.trimEnd('/')

    override suspend fun chat(messages: List<ChatTurn>, systemPrompt: String?, language: String): Result<String> =
        generate(messages, systemPrompt, language, useSearch = false).map { it.first }

    private suspend fun generate(
        messages: List<ChatTurn>, systemPrompt: String?, language: String, useSearch: Boolean
    ): Result<Pair<String, List<SourceLink>>> = withContext(Dispatchers.IO) {
        if (backendUrl.contains("YOUR-BACKEND-DOMAIN")) return@withContext Result.failure(IllegalStateException(
            "ASTRA backend अभी configure नहीं है। पहले सुरक्षित backend deploy करके AI_BACKEND_URL सेट करें।"))
        try {
            val contents = JSONArray()
            messages.filter { it.content.isNotBlank() }.forEach { msg ->
                contents.put(JSONObject().put("role", if (msg.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", msg.content))))
            }
            val body = JSONObject().put("model", model).put("contents", contents)
            val instruction = buildString {
                append(systemPrompt ?: "You are ASTRA QUANTUM AI, a helpful and honest assistant. Creator by Bittu Pandit.")
                append("\nRespond in ").append(if (language == "hi") "Hindi" else "English")
                append(". Do not invent facts or citations. Clearly state uncertainty.")
            }
            body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction))))
            if (useSearch) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val request = Request.Builder()
                .url("$backendUrl/v1/generate")
                .post(body.toString().toRequestBody(jsonMedia)).build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) return@withContext Result.failure(
                    Exception("Gemini API ${response.code}: ${raw.take(900)}"))
                val json = JSONObject(raw)
                val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?: return@withContext Result.failure(Exception("AI से कोई उत्तर नहीं मिला।"))
                val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                val answer = buildString {
                    for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
                }.trim()
                if (answer.isBlank()) return@withContext Result.failure(Exception("AI का उत्तर खाली मिला।"))
                val sources = mutableListOf<SourceLink>()
                val chunks = candidate.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                if (chunks != null) for (i in 0 until chunks.length()) {
                    val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                    val url = web.optString("uri")
                    if (url.startsWith("https://") || url.startsWith("http://"))
                        sources.add(SourceLink(web.optString("title", url), url))
                }
                Result.success(answer to sources.distinctBy { it.url })
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    override suspend fun analyzeImage(
        imageBytes: ByteArray, mimeType: String, prompt: String, language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (backendUrl.contains("YOUR-BACKEND-DOMAIN")) return@withContext Result.failure(IllegalStateException(
            "ASTRA backend अभी configure नहीं है। पहले सुरक्षित backend deploy करके AI_BACKEND_URL सेट करें।"))
        if (imageBytes.isEmpty()) return@withContext Result.failure(IllegalArgumentException("Image खाली है।"))
        try {
            val encoded = android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP)
            val parts = JSONArray()
                .put(JSONObject().put("text", (if (language == "hi") "हिंदी में विश्लेषण करो। " else "Analyze this image. ") + prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", mimeType).put("data", encoded)))
            val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
            val body = JSONObject().put("model", model).put("contents", contents)
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                    "You are ASTRA QUANTUM AI. Describe only visible evidence, distinguish uncertainty, and never infer sensitive traits. Creator by Bittu Pandit."))))
            val request = Request.Builder()
                .url("$backendUrl/v1/generate")
                .post(body.toString().toRequestBody(jsonMedia)).build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) return@withContext Result.failure(Exception("Gemini API ${response.code}: ${raw.take(700)}"))
                val candidate = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                    ?: return@withContext Result.failure(Exception("AI से image analysis नहीं मिला।"))
                val responseParts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                val answer = buildString { for (i in 0 until responseParts.length()) append(responseParts.optJSONObject(i)?.optString("text").orEmpty()) }.trim()
                if (answer.isBlank()) Result.failure(Exception("Image analysis खाली मिला।")) else Result.success(answer)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    override suspend fun research(query: String, language: String): Result<ResearchReport> {
        val prompt = if (language == "hi")
            "इस विषय पर वेब सर्च के आधार पर शोध करो: $query. पहले संक्षिप्त सारांश, फिर मुख्य तथ्य, फिर विवाद/अनिश्चितताएँ और अंत में निष्कर्ष दो। केवल खोज से मिले स्रोतों पर आधारित दावे करो।"
        else "Research this topic using web search: $query. Give an executive summary, key findings, uncertainties or disagreements, and a conclusion. Ground factual claims in retrieved sources."
        return generate(listOf(ChatTurn("user", prompt)), "You are a careful research analyst. Use Google Search grounding and distinguish evidence from inference.", language, true)
            .map { (answer, sources) -> ResearchReport(answer.lineSequence().firstOrNull()?.take(500) ?: answer.take(500),
                listOf(ResearchSection(if (language == "hi") "शोध रिपोर्ट" else "Research report", answer)), sources) }
    }
}
