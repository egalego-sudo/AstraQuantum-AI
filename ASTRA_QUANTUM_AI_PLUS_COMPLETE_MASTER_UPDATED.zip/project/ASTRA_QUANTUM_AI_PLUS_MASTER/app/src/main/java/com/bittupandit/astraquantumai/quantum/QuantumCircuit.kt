package com.bittupandit.astraquantumai.quantum

/**
 * Educational quantum circuit using a proper multi-qubit state-vector simulator.
 * Supports entanglement via CNOT. Classical simulation only.
 */
data class GateOperation(
    val name: String,
    val qubitIndex: Int,
    val targetIndex: Int? = null,
    val description: String
)

class QuantumCircuit(val numQubits: Int = 3) {

    private val simulator = StateVectorSimulator(numQubits)
    val history: MutableList<GateOperation> = mutableListOf()
    var lastMeasurement: Int? = null
        private set

    fun reset() {
        simulator.reset()
        history.clear()
        lastMeasurement = null
    }

    fun applyHadamard(qubit: Int) {
        simulator.hadamard(qubit)
        history.add(GateOperation("H", qubit, null, "Hadamard on qubit $qubit – creates superposition"))
    }

    fun applyPauliX(qubit: Int) {
        simulator.pauliX(qubit)
        history.add(GateOperation("X", qubit, null, "Pauli-X (NOT) on qubit $qubit"))
    }

    fun applyPauliY(qubit: Int) {
        simulator.pauliY(qubit)
        history.add(GateOperation("Y", qubit, null, "Pauli-Y on qubit $qubit"))
    }

    fun applyPauliZ(qubit: Int) {
        simulator.pauliZ(qubit)
        history.add(GateOperation("Z", qubit, null, "Pauli-Z on qubit $qubit – phase flip"))
    }

    fun applyCNOT(control: Int, target: Int) {
        simulator.cnot(control, target)
        history.add(GateOperation("CNOT", control, target, "CNOT control=$control target=$target (can create entanglement)"))
    }

    /** Run a small educational Grover search on this circuit's state-vector simulator. */
    fun runGrover(markedIndex: Int): Int {
        require(markedIndex in 0 until (1 shl numQubits))
        reset()
        for (q in 0 until numQubits) applyHadamard(q)
        val iterations = maxOf(1, kotlin.math.floor(kotlin.math.PI / 4.0 * kotlin.math.sqrt((1 shl numQubits).toDouble())).toInt())
        repeat(iterations) {
            simulator.groverSearch(markedIndex)
            history.add(GateOperation("GROVER", -1, null, "Grover oracle + diffusion iteration ${it + 1}; target |${Integer.toBinaryString(markedIndex).padStart(numQubits, '0')}⟩"))
        }
        return iterations
    }

    fun measureAll(): Int {
        val result = simulator.measureAll()
        lastMeasurement = result
        val bits = Integer.toBinaryString(result).padStart(numQubits, '0')
        history.add(GateOperation("MEASURE", -1, null, "Measured all qubits → |$bits⟩ ($result)"))
        return result
    }

    fun getMarginalProbabilities(): List<Pair<Double, Double>> =
        simulator.qubitMarginalProbabilities()

    fun getFullStateDescription(): String = simulator.stateDescription()

    fun getProbabilities(): DoubleArray = simulator.probabilities()

    fun explanationForLastOp(): String =
        history.lastOrNull()?.description ?: "Circuit is empty. Apply gates to begin."
}
