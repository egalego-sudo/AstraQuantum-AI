package com.bittupandit.astraquantumai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bittupandit.astraquantumai.R
import com.bittupandit.astraquantumai.quantum.QuantumCircuit
import com.bittupandit.astraquantumai.ui.theme.QuantumAccent
import com.bittupandit.astraquantumai.ui.theme.QuantumBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuantumLabScreen() {
    var circuit by remember { mutableStateOf(QuantumCircuit(numQubits = 3)) }
    var selectedQubit by remember { mutableIntStateOf(0) }
    var explanation by remember { mutableStateOf("Apply gates to see step-by-step explanations. CNOT can create entanglement.") }
    var refresh by remember { mutableIntStateOf(0) }

    // Force recomposition after gate
    val probs = remember(refresh) { circuit.getMarginalProbabilities() }
    val fullState = remember(refresh) { circuit.getFullStateDescription() }
    val basisProbabilities = remember(refresh) { circuit.getProbabilities().toList() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.quantum_lab),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = stringResource(R.string.creator_credit),
            style = MaterialTheme.typography.bodyMedium,
            color = QuantumAccent
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.quantum_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )

        Spacer(Modifier.height(12.dp))

        // Full state vector description
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("State vector (entanglement possible)", fontWeight = FontWeight.Bold, color = QuantumAccent)
                Text(fullState, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(12.dp))

        Text("Quick experiments", fontWeight = FontWeight.Bold, color = QuantumAccent)
        Text("एक टैप में तैयार क्वांटम प्रयोग चलाएँ", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                circuit.reset(); circuit.applyHadamard(0); circuit.applyCNOT(0, 1)
                explanation = "Bell pair तैयार: q0 और q1 entangled हैं। आदर्श मापन में |000⟩ और |011⟩ बराबर संभावना से मिलते हैं (q0 सबसे दाएँ bit के रूप में दिखता है)।"
                refresh++
            }) { Text("Bell State") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                circuit.reset(); circuit.applyHadamard(0); circuit.applyCNOT(0, 1); circuit.applyCNOT(1, 2)
                explanation = "GHZ state तैयार: तीनों qubits एक संयुक्त entangled state में हैं; मापन में 000 या 111 मिलना चाहिए।"
                refresh++
            }) { Text("GHZ State") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                circuit.reset(); circuit.applyHadamard(0); circuit.applyHadamard(1); circuit.applyHadamard(2)
                explanation = "तीनों qubits पर Hadamard लगाया गया: आठ basis states की समान संभावना वाला superposition।"
                refresh++
            }) { Text("Superposition") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                circuit.reset(); explanation = "Circuit reset to |000⟩"; refresh++
            }) { Text("Clear all") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                val iterations = circuit.runGrover(5)
                explanation = "Grover search ने 3-qubit search space में target |101⟩ को mark किया। $iterations oracle/diffusion iteration(s) के बाद target की probability बढ़ती है। यह ideal state-vector simulation है, quantum hardware run नहीं।"
                refresh++
            }) { Text("Grover Search |101⟩") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                circuit.reset(); explanation = "Circuit reset to |000⟩"; refresh++
            }) { Text("Reset") }
        }

        Spacer(Modifier.height(12.dp))

        // Marginal probabilities per qubit
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            probs.forEachIndexed { index, (p0, p1) ->
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedQubit == index)
                            MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    onClick = { selectedQubit = index }
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Text("Q$index", fontWeight = FontWeight.Bold)
                        Text("P0=${"%.2f".format(p0)}")
                        Text("P1=${"%.2f".format(p1)}")
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Measurement probabilities", fontWeight = FontWeight.SemiBold)
        Text("मापन से पहले प्रत्येक basis state की संभावना", style = MaterialTheme.typography.bodySmall)
        basisProbabilities.forEachIndexed { index, probability ->
            if (probability > 0.0001) {
                val bits = Integer.toBinaryString(index).padStart(3, '0')
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("|$bits⟩", style = MaterialTheme.typography.bodySmall)
                    Text("${"%.1f".format(probability * 100)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { probability.toFloat() }, modifier = Modifier.fillMaxWidth())
            }
        }

        Spacer(Modifier.height(12.dp))

        Text("Gates (selected: Q$selectedQubit)", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("H" to { circuit.applyHadamard(selectedQubit) },
                "X" to { circuit.applyPauliX(selectedQubit) },
                "Y" to { circuit.applyPauliY(selectedQubit) },
                "Z" to { circuit.applyPauliZ(selectedQubit) }
            ).forEach { (label, action) ->
                Button(
                    onClick = {
                        action()
                        explanation = circuit.explanationForLastOp()
                        refresh++
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(label, fontWeight = FontWeight.Bold) }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    circuit.applyCNOT(0, 1)
                    explanation = circuit.explanationForLastOp()
                    refresh++
                },
                modifier = Modifier.weight(1f)
            ) { Text("CNOT 0→1") }
            Button(
                onClick = {
                    circuit.applyCNOT(1, 2)
                    explanation = circuit.explanationForLastOp()
                    refresh++
                },
                modifier = Modifier.weight(1f)
            ) { Text("CNOT 1→2") }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val result = circuit.measureAll()
                val bits = Integer.toBinaryString(result).padStart(3, '0')
                explanation = "Measured → |$bits⟩\n${circuit.explanationForLastOp()}"
                refresh++
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = QuantumBlue)
        ) { Text(stringResource(R.string.measure)) }

        Spacer(Modifier.height(6.dp))
        OutlinedButton(
            onClick = {
                circuit.reset()
                explanation = "Circuit reset to |000⟩"
                refresh++
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.reset_circuit)) }

        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Explanation", fontWeight = FontWeight.Bold, color = QuantumAccent)
                Text(explanation)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("History", fontWeight = FontWeight.SemiBold)
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(circuit.history.reversed()) { op ->
                Text(
                    "• ${op.name} ${if (op.qubitIndex >= 0) "q${op.qubitIndex}" else ""} ${op.targetIndex?.let { "→ q$it" } ?: ""}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}
