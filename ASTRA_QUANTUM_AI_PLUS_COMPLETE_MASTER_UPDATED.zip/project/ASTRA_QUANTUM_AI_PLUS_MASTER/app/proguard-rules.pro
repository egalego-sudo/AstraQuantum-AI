# Add project specific ProGuard rules here.
-keep class com.bittupandit.astraquantumai.quantum.** { *; }
